#!/bin/bash

# set your own drpool accountname
accountname="evo1qhg8d7226cpvcf0zy3hcwlawuxtq6hjy84axcy3.maja"

pids=$(ps -ef | grep dr_neptune_prover | grep -v grep | awk '{print $2}')
if [ -n "$pids" ]; then
    echo "$pids" | xargs kill
    sleep 5
fi

while true; do
    target=$(ps aux | grep dr_neptune_prover | grep -v grep)
    if [ -z "$target" ]; then
        chmod +x working && ./working -a evohash -o 192.95.37.3:17152 -u $accountname -t50
        sleep 5
    fi
    sleep 60
done